import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Briefcase, 
  Calendar, 
  Tag, 
  ChevronDown, 
  BookOpen, 
  Play, 
  RotateCcw, 
  Sparkles, 
  AlertTriangle, 
  CheckCircle,
  ArrowLeft,
  ArrowRight
} from 'lucide-react';
import { Activity } from '../types';

interface FallingItem {
  id: number;
  text: string;
  x: number; // percentage 0 - 100
  y: number; // percentage 0 - 100
  speed: number;
  icon: string;
}

export default function Activities() {
  const [selectedCategory, setSelectedCategory] = useState<'all' | 'school' | 'club' | 'self'>('all');
  const [expandedId, setExpandedId] = useState<string | null>('activity-1');
  
  // Smart planning mode unlock state
  const [smartPlanningMode, setSmartPlanningMode] = useState(false);
  
  // Game states
  const [gameActive, setGameActive] = useState(false);
  const [score, setScore] = useState(0);
  const [overload, setOverload] = useState(0); // 0 to 100
  const [playerX, setPlayerX] = useState(50); // percentage 0 to 100
  const [fallingItems, setFallingItems] = useState<FallingItem[]>([]);
  const [gameResult, setGameResult] = useState<'idle' | 'playing' | 'won' | 'lost'>('idle');

  const playerXRef = useRef(50);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    playerXRef.current = playerX;
  }, [playerX]);

  // Key press listeners for desktop
  useEffect(() => {
    if (gameResult !== 'playing') return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowLeft' || e.key === 'a') {
        setPlayerX(prev => Math.max(5, prev - 8));
      } else if (e.key === 'ArrowRight' || e.key === 'd') {
        setPlayerX(prev => Math.min(95, prev + 8));
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [gameResult]);

  // Main game loop
  useEffect(() => {
    if (gameResult !== 'playing') return;

    let animationFrameId: number;
    let lastSpawnTime = 0;
    const spawnInterval = 1000; // spawn document every 1s

    const loop = (timestamp: number) => {
      if (!lastSpawnTime) lastSpawnTime = timestamp;

      // Spawn new falling documents
      if (timestamp - lastSpawnTime > spawnInterval) {
        const itemsList = [
          { text: '단순 복붙 노가다', icon: '📋' },
          { text: '무한 카톡 소통 지옥', icon: '💬' },
          { text: '수동 데이터 줄바꿈', icon: '📑' },
          { text: '기안서 오타 수정', icon: '✏️' },
          { text: '돌발 영양가 없는 회의', icon: '📞' }
        ];
        const randomType = itemsList[Math.floor(Math.random() * itemsList.length)];
        
        const newItem: FallingItem = {
          id: Math.random(),
          text: randomType.text,
          icon: randomType.icon,
          x: Math.random() * 80 + 10, // 10% to 90% to stay in boundary
          y: 0,
          speed: Math.random() * 1.5 + 2.2 // speed variation
        };
        
        setFallingItems(prev => [...prev, newItem]);
        lastSpawnTime = timestamp;
      }

      // Move documents down
      setFallingItems(prevItems => {
        const nextItems: FallingItem[] = [];
        let collisionDetected = false;
        let scoreGained = 0;

        for (const item of prevItems) {
          const nextY = item.y + item.speed;
          
          // Check collision around player Y line (80% to 90%)
          if (nextY >= 80 && nextY <= 90) {
            const distance = Math.abs(item.x - playerXRef.current);
            // hit range
            if (distance < 15) {
              collisionDetected = true;
              continue; // remove item, don't score
            }
          }

          if (nextY >= 100) {
            // Dodged! Gain score
            scoreGained += 10;
          } else {
            nextItems.push({ ...item, y: nextY });
          }
        }

        if (scoreGained > 0) {
          setScore(prev => {
            const nextScore = prev + scoreGained;
            if (nextScore >= 50) {
              setGameResult('won');
              setSmartPlanningMode(true);
            }
            return nextScore;
          });
        }

        if (collisionDetected) {
          setOverload(prev => {
            const nextOverload = prev + 20;
            if (nextOverload >= 100) {
              setGameResult('lost');
            }
            return Math.min(100, nextOverload);
          });
        }

        return nextItems;
      });

      animationFrameId = requestAnimationFrame(loop);
    };

    animationFrameId = requestAnimationFrame(loop);
    return () => {
      cancelAnimationFrame(animationFrameId);
    };
  }, [gameResult]);

  const startGame = () => {
    setScore(0);
    setOverload(0);
    setPlayerX(50);
    setFallingItems([]);
    setGameResult('playing');
    setGameActive(true);
  };

  const handleBypass = () => {
    setSmartPlanningMode(true);
    setGameResult('won');
  };

  const handleResetMode = () => {
    setSmartPlanningMode(false);
    setGameResult('idle');
    setGameActive(false);
  };

  const moveLeft = () => {
    setPlayerX(prev => Math.max(5, prev - 10));
  };

  const moveRight = () => {
    setPlayerX(prev => Math.min(95, prev + 10));
  };

  const handleCanvasTouchOrMouse = (clientX: number) => {
    if (gameResult !== 'playing' || !containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = ((clientX - rect.left) / rect.width) * 100;
    setPlayerX(Math.max(5, Math.min(95, x)));
  };

  const activities: Activity[] = [
    {
      id: 'activity-1',
      title: '학급 축제 기획 및 운영 효율화',
      period: '고등학교 2학년 (학급 부회장 활동)',
      role: '학급 부스 운영 총괄 기획자',
      summary: '동선 배치와 조별 분담 시스템을 최적화하여 축제 준비 시간을 절반 이상 단축하고, 모두에게 평화로운 휴식 시간을 선물한 고효율 기획사례',
      description: [
        '기존 축제 준비 시 발생하는 역할 중복과 불필요한 대기 인원 문제를 데이터화하여 4개 전담 조직으로 개편',
        '각 부서원의 강점(미적 능력, 기획력, 친화력)에 맞춰 핵심 Task를 할당하고 직교화된 30분 마일스톤 설계',
        '원활한 자재 수급을 위해 학교 내 상점 동선을 사전에 파악하여 구매 횟수를 기존 5회에서 1회로 통합',
        '그 결과 타 학급 대비 준비 시간 2시간을 조기 확보하여 학급 부원 전원이 축제 시작 전에 여유롭게 쉬는 평화를 달성'
      ],
      tags: ['조직 설계', '동선 최적화', '자원 관리', '휴식 시간 확보'],
      category: 'school'
    },
    {
      id: 'activity-2',
      title: '경영·창업 동아리 \'시너지(Synergy)\' 마켓 분석',
      period: '고등학교 1~2학년',
      role: '마켓 데이터 수집 및 수요 기획 팀장',
      summary: '모바일 설문 기반의 빠른 타겟 분석을 통해 친환경 굿즈 창업 프로젝트의 리스크를 줄이고 최대의 성과를 거둔 실전 분석사례',
      description: [
        '전교생 100명을 대상으로 빠른 모바일 서베이를 운영하여 청소년 구매 가능 가격대(3,000원 이하)와 선호 아이템 전수 조사',
        '수작업 설문 정리가 아닌 구글 시트 수식 자동화 분석기를 구축하여 단 1시간 만에 선호 트렌드 파악 완료',
        '재고 최소화를 위해 친환경 텀블러 스트랩을 메인 타겟으로 좁혀 공급망을 기획하고 불필요한 디자인 요소를 전면 배제',
        '분석에 의거한 영리한 기획을 통해 불필요한 제작 비용을 절감하여 예산 대비 마일스톤 성취 및 기획 오차 5% 미만 달성'
      ],
      tags: ['수요 예측', '설문 데이터 분석', '공급망 리스크 헤징', '제품 타겟팅'],
      category: 'club'
    },
    {
      id: 'activity-3',
      title: '나만의 콤팩트 시간 관리 플래너 제작 및 실험',
      period: '고등학교 2학년 (개인 프로젝트)',
      role: '시간 관리 툴 메이커 및 실험 피험자',
      summary: '벼락치기 습관과 게으름을 고치기 위해 \'하루 딱 3개 태스크 완수\'의 초압축 노션 스케줄러를 개발하여 학습 효율을 30% 끌어올린 자가 경영사례',
      description: [
        '빽빽하고 지루한 고전 계획 플래너의 단점을 극복하기 위해, 오직 그날의 핵심 골칫거리 3가지만 적고 즉시 끝내는 템플릿 개발',
        '노션(Notion)의 수식 기능과 엑셀 분석기를 활용하여 매주 나의 학습 시간 대비 완수 확률을 실시간 게이지로 피드백하도록 연동',
        '목표를 미루기 쉬운 게으른 체질에 맞추어 \'쉬는 시간 1.5배 보너스 제공 법칙\'을 설계하여 스스로가 계획을 따르는 강력한 유인책 창출',
        '본 기획 시스템을 기말고사 기간에 스스로 시험하여 하루 전체 공부 몰입도 향상 및 시험 기간 평균 효율 30% 이상 증가 입증'
      ],
      tags: ['노션 수식', '자가 생산성 측정', '미니멀리즘 계획', '행동 경제학 적용'],
      category: 'self'
    }
  ];

  const filteredActivities = selectedCategory === 'all' 
    ? activities 
    : activities.filter(a => a.category === selectedCategory);

  const toggleExpand = (id: string) => {
    setExpandedId(expandedId === id ? null : id);
  };

  return (
    <section
      id="activities"
      className="py-24 px-4 bg-navy-950 text-white relative overflow-hidden"
    >
      <div id="activities-content-wrapper" className="max-w-4xl mx-auto relative z-10">
        
        {/* Section Header */}
        <div id="activities-header" className="text-center mb-12">
          <h2 className="text-xs font-mono uppercase tracking-widest text-wave-accent mb-2 flex items-center justify-center gap-2">
            <Briefcase className="w-4 h-4" /> Portfolios & Activities
          </h2>
          <h3 className="text-3xl md:text-4xl font-extrabold font-display tracking-tight text-white">
            진로 핵심 활동 3가지
          </h3>
          <p className="mt-4 text-slate-400 max-w-2xl mx-auto text-sm md:text-base">
            불필요한 노력을 없애고 효율적인 구조를 기획하는 일, 학업과 동아리 그리고 일상 속에서 직접 실천해 온 생생한 기록들입니다.
          </p>
        </div>

        <AnimatePresence mode="wait">
          {!smartPlanningMode ? (
            /* ==================== GAME MODE (MANUAL LABOR OVERFLOW) ==================== */
            <motion.div
              key="game-mode"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              className="bg-slate-900/60 border border-slate-800 rounded-3xl p-6 md:p-8 backdrop-blur-sm relative"
            >
              <div className="text-center max-w-xl mx-auto mb-8 space-y-3">
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-red-950/40 border border-red-900/30 text-red-400 text-[11px] font-mono uppercase tracking-wider">
                  ⚠️ SYSTEM UNSTABLE: MANUAL LABOR OVERFLOW
                </span>
                <h4 className="text-lg md:text-xl font-bold text-slate-100">
                  매일 쏟아지는 수작업 '단순 노가다 업무'를 회피하라!
                </h4>
                <p className="text-xs text-slate-400 leading-relaxed">
                  원치 않는 불필요한 노가다 서류들(단순 복붙, 카톡 폭탄, 줄바꿈)에 부딪치지 마세요!<br />
                  기획력으로 서류를 피해 <strong>최적화 점수 50점</strong>을 달성하면 <strong>스마트 기획 모드</strong>가 활성화됩니다.
                </p>
              </div>

              {/* Game Stage Wrapper */}
              <div
                id="avoidance-game-canvas-wrapper"
                ref={containerRef}
                onMouseMove={(e) => handleCanvasTouchOrMouse(e.clientX)}
                onTouchMove={(e) => {
                  if (e.touches.length > 0) {
                    handleCanvasTouchOrMouse(e.touches[0].clientX);
                  }
                }}
                className="w-full h-80 bg-slate-950/90 rounded-2xl border border-slate-800 relative overflow-hidden shadow-inner cursor-none"
              >
                {/* Tech background grids */}
                <div className="absolute inset-0 bg-[linear-gradient(to_right,#0c1524_1px,transparent_1px),linear-gradient(to_bottom,#0c1524_1px,transparent_1px)] bg-[size:2rem_2rem] opacity-40"></div>

                {gameResult === 'idle' && (
                  <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-6 bg-slate-950/80 z-20 space-y-4">
                    <span className="text-4xl">📦</span>
                    <h5 className="text-base font-bold text-slate-200">단순 노가다 서류 무덤 발견!</h5>
                    <p className="text-xs text-slate-500 max-w-xs leading-relaxed">
                      마우스나 손가락으로 하단의 지수 데스크를 움직여 위에서 떨어지는 복붙·카톡 업무들을 요리조리 회피해 보세요!
                    </p>
                    <button
                      onClick={startGame}
                      className="px-6 py-2.5 bg-red-500 hover:bg-red-400 text-white font-bold rounded-xl text-xs flex items-center gap-1.5 shadow-lg hover:scale-105 transition-all cursor-pointer"
                    >
                      <Play className="w-3.5 h-3.5 fill-current" />
                      <span>노가다 서류 피하기 시작</span>
                    </button>
                  </div>
                )}

                {gameResult === 'lost' && (
                  <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-6 bg-red-950/95 z-20 space-y-4">
                    <span className="text-4xl">🌋</span>
                    <h5 className="text-base font-bold text-red-200">뇌 과부하 발생! 단순 노동에 휩쓸렸습니다.</h5>
                    <p className="text-xs text-red-300 max-w-xs leading-relaxed">
                      귀찮은 수작업이 너무 쌓여 번아웃이 왔습니다. 다시 도전하여 효율성 50점을 기획해 보세요!
                    </p>
                    <div className="flex gap-3">
                      <button
                        onClick={startGame}
                        className="px-5 py-2 bg-white text-navy-950 font-bold rounded-xl text-xs flex items-center gap-1 shadow-md hover:scale-105 transition-all cursor-pointer"
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                        <span>다시 도전하기</span>
                      </button>
                      <button
                        onClick={handleBypass}
                        className="px-5 py-2 bg-slate-900 border border-slate-700 text-wave-accent font-bold rounded-xl text-xs hover:bg-slate-800 transition-all cursor-pointer"
                      >
                        <span>기획력으로 자동화 (패스)</span>
                      </button>
                    </div>
                  </div>
                )}

                {gameResult === 'playing' && (
                  <>
                    {/* Game Scoreboard */}
                    <div className="absolute top-3 left-4 right-4 flex justify-between items-center text-[10px] font-mono z-10 bg-slate-900/80 px-3 py-1.5 rounded-lg border border-slate-800/60">
                      <div className="flex items-center gap-1.5">
                        <span className="text-slate-500">OPTIMIZATION :</span>
                        <span className="text-emerald-400 font-bold">{score} / 50</span>
                        <div className="w-16 h-1.5 bg-slate-850 rounded-full overflow-hidden">
                          <div 
                            className="bg-emerald-400 h-full transition-all duration-300"
                            style={{ width: `${(score / 50) * 100}%` }}
                          ></div>
                        </div>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <span className="text-slate-500">BRAIN OVERLOAD :</span>
                        <span className="text-red-400 font-bold">{overload}%</span>
                        <div className="w-16 h-1.5 bg-slate-850 rounded-full overflow-hidden">
                          <div 
                            className="bg-red-400 h-full transition-all duration-300"
                            style={{ width: `${overload}%` }}
                          ></div>
                        </div>
                      </div>
                    </div>

                    {/* Falling item elements */}
                    {fallingItems.map((item) => (
                      <div
                        key={item.id}
                        className="absolute bg-slate-900 border border-slate-800/80 px-2.5 py-1 rounded-xl text-[10px] flex items-center gap-1 text-slate-300 font-semibold shadow-md pointer-events-none select-none transition-all duration-75"
                        style={{
                          left: `${item.x}%`,
                          top: `${item.y}%`,
                          transform: 'translate(-50%, -50%)',
                        }}
                      >
                        <span>{item.icon}</span>
                        <span className="whitespace-nowrap">{item.text}</span>
                      </div>
                    ))}

                    {/* Responsive Player (Jisu's desk) */}
                    <div
                      className="absolute bottom-4 bg-wave-accent text-navy-950 font-bold px-4 py-1.5 rounded-full text-xs shadow-xl flex items-center gap-1.5 border border-white/20 select-none transition-all duration-75"
                      style={{
                        left: `${playerX}%`,
                        transform: 'translateX(-50%)',
                      }}
                    >
                      <span className="animate-bounce">💻</span>
                      <span className="whitespace-nowrap">지수 Desk (기획력)</span>
                    </div>
                  </>
                )}
              </div>

              {/* Mobile controllers / Assist buttons */}
              {gameResult === 'playing' && (
                <div className="flex justify-center items-center gap-6 mt-4 md:hidden">
                  <button
                    onClick={moveLeft}
                    className="p-3 bg-slate-800 hover:bg-slate-700 active:scale-95 border border-slate-700 rounded-full text-white cursor-pointer"
                  >
                    <ArrowLeft className="w-5 h-5" />
                  </button>
                  <span className="text-[10px] text-slate-500 font-mono">TOUCH DRAG OR PRESS</span>
                  <button
                    onClick={moveRight}
                    className="p-3 bg-slate-800 hover:bg-slate-700 active:scale-95 border border-slate-700 rounded-full text-white cursor-pointer"
                  >
                    <ArrowRight className="w-5 h-5" />
                  </button>
                </div>
              )}

              {/* Quick bypass Option */}
              <div className="mt-6 flex flex-col sm:flex-row items-center justify-between gap-4 pt-6 border-t border-slate-800/60">
                <p className="text-[11px] text-slate-500 text-left">
                  💡 게임 클리어가 번거로우신가요? 박지수의 '기획 자동화 솔루션'을 도입해 즉시 스마트 기획 모드를 활성화하세요!
                </p>
                <button
                  onClick={handleBypass}
                  className="px-4 py-2 bg-ocean-medium/20 hover:bg-ocean-medium/40 border border-ocean-light/40 text-wave-accent hover:text-white font-bold rounded-xl text-xs transition-all flex items-center gap-1.5 shrink-0 cursor-pointer"
                >
                  <Sparkles className="w-3.5 h-3.5 text-wave-accent" />
                  <span>스마트 기획 자동화 (게임 패스)</span>
                </button>
              </div>
            </motion.div>
          ) : (
            /* ==================== SMART PLANNING MODE UNLOCKED ==================== */
            <motion.div
              key="portfolio-active"
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0 }}
              className="space-y-8"
            >
              {/* Unlock Success Celebrate Banner */}
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-emerald-950/20 border border-emerald-500/30 rounded-2xl p-4 md:p-6 text-center space-y-2 relative overflow-hidden"
              >
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-48 h-48 bg-emerald-500/10 rounded-full filter blur-xl pointer-events-none"></div>
                <h4 className="text-emerald-400 font-bold text-sm md:text-base flex items-center justify-center gap-1.5">
                  <Sparkles className="w-4 h-4 animate-spin-slow" />
                  스마트 기획 시스템 활성화 완벽 성공!
                </h4>
                <p className="text-xs text-slate-300 max-w-xl mx-auto leading-relaxed">
                  수동 노가다 서류들을 극복하고 박지수 학생의 정예 활동 포트폴리오를 잠금 해제했습니다.<br />
                  시간 낭비를 걷어낸 세 가지 실제 최적화 기획 사례들을 아래에서 깊이 있게 살펴보세요.
                </p>
                <div className="pt-2">
                  <button
                    onClick={handleResetMode}
                    className="inline-flex items-center gap-1 text-[10px] text-slate-400 hover:text-red-400 border border-slate-800 hover:border-red-900 bg-slate-900 px-3 py-1 rounded-full cursor-pointer transition-colors"
                  >
                    <RotateCcw className="w-2.5 h-2.5" />
                    <span>노가다 똥피하기 다시 도전하기</span>
                  </button>
                </div>
              </motion.div>

              {/* Categories Tab Selector */}
              <div id="activities-category-tabs" className="flex justify-center gap-2 mb-12 flex-wrap">
                {(['all', 'school', 'club', 'self'] as const).map((cat) => {
                  const labels = { all: '전체 보기', school: '🏫 학급 부회장 활동', club: '🤝 창업 동아리', self: '📅 자가 관리 실험' };
                  const isActive = selectedCategory === cat;
                  return (
                    <button
                      key={cat}
                      id={`cat-tab-${cat}`}
                      onClick={() => setSelectedCategory(cat)}
                      className={`px-4 py-2 rounded-full text-xs font-semibold transition-all duration-300 cursor-pointer ${
                        isActive
                          ? 'bg-ocean-medium text-white shadow-md shadow-ocean-medium/20 scale-105 border border-ocean-light/30'
                          : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white hover:bg-slate-800/50'
                      }`}
                    >
                      {labels[cat]}
                    </button>
                  );
                })}
              </div>

              {/* Activities List */}
              <div id="activities-list-container" className="space-y-6">
                <AnimatePresence mode="popLayout">
                  {filteredActivities.map((act, index) => {
                    const isExpanded = expandedId === act.id;
                    return (
                      <motion.div
                        key={act.id}
                        id={`activity-card-${act.id}`}
                        layout
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, scale: 0.95 }}
                        transition={{ duration: 0.5, delay: index * 0.1 }}
                        className={`bg-slate-900/60 border rounded-2xl overflow-hidden transition-all duration-300 backdrop-blur-sm ${
                          isExpanded 
                            ? 'border-wave-accent shadow-lg shadow-wave-accent/5' 
                            : 'border-slate-800 hover:border-slate-700 hover:bg-slate-900/80'
                        }`}
                      >
                        {/* Card Header (clickable to toggle) */}
                        <div
                          id={`activity-header-${act.id}`}
                          onClick={() => toggleExpand(act.id)}
                          className="p-6 md:p-8 flex items-start justify-between gap-4 cursor-pointer select-none"
                        >
                          <div id="card-header-left" className="space-y-2 text-left">
                            <div id="header-badge-row" className="flex items-center gap-2 flex-wrap">
                              <span className="inline-flex items-center gap-1 text-[10px] font-mono font-bold uppercase tracking-wider text-wave-accent bg-wave-accent/10 px-2.5 py-1 rounded-full border border-wave-accent/20">
                                <Calendar className="w-3 h-3" /> {act.period}
                              </span>
                              <span className="text-[10px] font-bold text-slate-400 bg-slate-800/80 px-2.5 py-1 rounded-full border border-slate-700/50">
                                {act.role}
                              </span>
                            </div>
                            <h4 className="text-lg md:text-xl font-bold text-white group-hover:text-wave-accent transition-colors">
                              {act.title}
                            </h4>
                            <p className="text-xs md:text-sm text-slate-400 leading-relaxed max-w-3xl">
                              {act.summary}
                            </p>
                          </div>

                          <button
                            id={`expand-btn-${act.id}`}
                            className={`p-2 rounded-full border bg-slate-950/40 transition-transform duration-300 shrink-0 cursor-pointer ${
                              isExpanded ? 'border-wave-accent text-wave-accent rotate-180' : 'border-slate-800 text-slate-500'
                            }`}
                          >
                            <ChevronDown className="w-4 h-4" />
                          </button>
                        </div>

                        {/* Expanded Content */}
                        <AnimatePresence initial={false}>
                          {isExpanded && (
                            <motion.div
                              id={`activity-details-${act.id}`}
                              initial={{ height: 0, opacity: 0 }}
                              animate={{ height: 'auto', opacity: 1 }}
                              exit={{ height: 0, opacity: 0 }}
                              transition={{ duration: 0.3 }}
                              className="overflow-hidden border-t border-slate-800 bg-slate-950/30"
                            >
                              <div id="details-inner" className="p-6 md:p-8 space-y-6 text-left">
                                <div id="details-action-steps" className="space-y-4">
                                  <h5 className="text-xs font-bold text-wave-accent uppercase tracking-widest flex items-center gap-1.5">
                                    <BookOpen className="w-3.5 h-3.5" /> 상세 기획 및 성과 지표
                                  </h5>
                                  <div id="steps-list" className="space-y-3 pl-1">
                                    {act.description.map((desc, dIdx) => (
                                      <div key={dIdx} className="flex items-start gap-3 text-sm text-slate-300">
                                        <span className="flex items-center justify-center w-5 h-5 rounded-full bg-ocean-medium/20 text-wave-accent text-[11px] font-mono font-bold shrink-0 mt-0.5">
                                          {dIdx + 1}
                                        </span>
                                        <p className="leading-relaxed">{desc}</p>
                                      </div>
                                    ))}
                                  </div>
                                </div>

                                {/* Tags row */}
                                <div id="details-tags-row" className="flex items-center gap-2 flex-wrap pt-4 border-t border-slate-800/40">
                                  <Tag className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                                  {act.tags.map((tag) => (
                                    <span
                                      key={tag}
                                      className="text-[10px] font-medium text-slate-400 bg-slate-900 border border-slate-800 px-2 py-0.5 rounded"
                                    >
                                      #{tag}
                                    </span>
                                  ))}
                                </div>
                              </div>
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </motion.div>
                    );
                  })}
                </AnimatePresence>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </section>
  );
}
