import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Goal, Navigation, ToggleLeft, ToggleRight, CheckCircle2, ChevronRight, Activity, Cpu } from 'lucide-react';

export default function CareerGoal() {
  const [smartMode, setSmartMode] = useState(true);

  return (
    <section
      id="career"
      className="py-24 px-4 bg-gradient-to-b from-ocean-dark to-navy-950 text-white relative overflow-hidden"
    >
      <div id="career-bg-overlay" className="absolute inset-0 pointer-events-none opacity-5">
        <div id="career-bg-glow" className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-wave-accent rounded-full filter blur-[180px]"></div>
      </div>

      <div id="career-content-wrapper" className="max-w-4xl mx-auto relative z-10">
        {/* Section Header */}
        <div id="career-header" className="text-center mb-16">
          <h2 className="text-xs font-mono uppercase tracking-widest text-wave-accent mb-2 flex items-center justify-center gap-2">
            <Goal className="w-4 h-4" /> Career Vision
          </h2>
          <h3 className="text-3xl md:text-4xl font-extrabold font-display tracking-tight text-white">
            나의 진로 목표 : 경영 기획 사무원
          </h3>
          <p className="mt-4 text-slate-400 max-w-2xl mx-auto text-sm md:text-base">
            바다의 물길을 읽고 배의 방향을 잡는 항해사처럼, 기업의 자원을 분석하고 최적의 성장 경로를 설계합니다.
          </p>
        </div>

        {/* Goal Description Grid */}
        <div id="career-vision-layout" className="grid grid-cols-1 md:grid-cols-12 gap-8 items-stretch mb-12">
          {/* Main Statement */}
          <div id="career-main-statement" className="md:col-span-7 bg-slate-900/60 border border-slate-800 rounded-2xl p-6 md:p-8 flex flex-col justify-between backdrop-blur-sm">
            <div id="statement-header">
              <span className="text-xs font-mono text-wave-accent/80 block mb-3 uppercase tracking-wider">The Definition</span>
              <h4 className="text-xl md:text-2xl font-bold text-slate-100 mb-4 leading-snug">
                "단순한 노동이 아닌,<br />
                <span className="text-wave-accent">스마트한 최적화</span>를 통해 나아가는 사람"
              </h4>
              <p className="text-slate-300 text-sm md:text-base leading-relaxed mb-6">
                제가 생각하는 경영 기획은 한정된 시간과 자원 속에서 최소의 비효율로 최대의 시너지를 내는 전략을 설계하는 일입니다. 
                모든 구성원이 불필요한 반복 노동에서 벗어나 핵심 가치에 집중할 수 있도록 구조를 짜는 '스마트 오거나이저'를 꿈꿉니다.
              </p>
            </div>
            
            <div id="statement-footer" className="grid grid-cols-2 gap-4 pt-6 border-t border-slate-800 text-center">
              <div id="stat-focus" className="bg-slate-950/40 p-3 rounded-xl border border-slate-800/60">
                <div className="text-2xl font-black text-wave-accent font-mono">2028년</div>
                <div className="text-[10px] text-slate-400 mt-1">대학 진학 및 데이터 공부</div>
              </div>
              <div id="stat-target" className="bg-slate-950/40 p-3 rounded-xl border border-slate-800/60">
                <div className="text-2xl font-black text-blue-400 font-mono">100%</div>
                <div className="text-[10px] text-slate-400 mt-1">업무 효율 최적화 지향</div>
              </div>
            </div>
          </div>

          {/* Compass Graphic */}
          <div id="career-compass-graphic" className="md:col-span-5 bg-gradient-to-br from-slate-900/40 to-ocean-dark/40 border border-ocean-medium/20 rounded-2xl p-6 flex flex-col justify-center items-center text-center relative overflow-hidden backdrop-blur-sm">
            <div id="compass-outer-circle" className="w-36 h-36 rounded-full border-2 border-dashed border-wave-accent/40 flex items-center justify-center relative mb-4 animate-spin-slow">
              <div id="compass-inner-circle" className="w-28 h-28 rounded-full border border-wave-accent/20 flex items-center justify-center">
                <Navigation className="w-12 h-12 text-wave-accent transform rotate-45" />
              </div>
              <div className="absolute top-2 left-1/2 -translate-x-1/2 text-[9px] font-mono text-wave-accent font-bold">N</div>
              <div className="absolute bottom-2 left-1/2 -translate-x-1/2 text-[9px] font-mono text-slate-500">S</div>
              <div className="absolute left-2 top-1/2 -translate-y-1/2 text-[9px] font-mono text-slate-500">W</div>
              <div className="absolute right-2 top-1/2 -translate-y-1/2 text-[9px] font-mono text-slate-500">E</div>
            </div>
            <h5 className="text-base font-bold text-slate-200">경영의 나침반(Compass)</h5>
            <p className="text-xs text-slate-400 mt-2 max-w-[220px]">
              목표가 보이지 않는 어두운 밤바다에서도, 올바른 데이터 나침반을 설계해 안전한 길로 안내합니다.
            </p>
          </div>
        </div>

        {/* COMPARISON INTERACTIVE: Manual vs Smart Planning */}
        <div id="career-mode-interactive" className="bg-slate-900/60 border border-slate-800/80 rounded-2xl p-6 md:p-8 backdrop-blur-sm">
          <div id="mode-header" className="flex flex-col sm:flex-row items-center justify-between gap-4 mb-6">
            <div id="mode-title-wrapper">
              <h4 className="text-base font-bold text-slate-100 flex items-center gap-2">
                <Cpu className="w-5 h-5 text-wave-accent" />
                <span>업무 스타일 분석 : 단순 노가다 vs 스마트 기획</span>
              </h4>
              <p className="text-xs text-slate-400 mt-0.5">
                경영 기획이 왜 조직에 평화를 가져다 주는지 직관적으로 확인하세요.
              </p>
            </div>

            {/* Toggle Controls */}
            <div id="mode-toggle-wrapper" className="flex items-center gap-3">
              <span className={`text-xs font-semibold transition-colors duration-200 ${!smartMode ? 'text-red-400 font-bold' : 'text-slate-500'}`}>
                일반 노가다 업무
              </span>
              <button
                id="career-mode-toggle-btn"
                onClick={() => setSmartMode(!smartMode)}
                className="text-wave-accent hover:text-white transition-colors cursor-pointer"
              >
                {smartMode ? (
                  <ToggleRight className="w-10 h-10 text-wave-accent" />
                ) : (
                  <ToggleLeft className="w-10 h-10 text-slate-600" />
                )}
              </button>
              <span className={`text-xs font-semibold transition-colors duration-200 ${smartMode ? 'text-wave-accent font-bold' : 'text-slate-500'}`}>
                박지수식 스마트 기획
              </span>
            </div>
          </div>

          {/* Cards Area with AnimatePresence */}
          <div id="mode-cards-container" className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <AnimatePresence mode="wait">
              {smartMode ? (
                // SMART MODE
                <>
                  <motion.div
                    key="smart-input"
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 10 }}
                    className="bg-ocean-medium/10 border border-ocean-medium/40 p-5 rounded-xl space-y-3.5"
                  >
                    <div className="flex items-center gap-2 text-wave-accent font-bold text-sm">
                      <span className="p-1 rounded bg-ocean-medium/20 text-wave-accent">💡</span>
                      <span>스마트 기획 : 최소 인풋 (20% 노력)</span>
                    </div>
                    <ul className="space-y-2.5 text-xs text-slate-300">
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="w-4 h-4 text-wave-accent shrink-0 mt-0.5" />
                        <span><strong>원페이지 가이드라인 구축</strong>: 핵심 지표와 가이드를 명확히 지정해 의사소통 혼선을 사전에 제거</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="w-4 h-4 text-wave-accent shrink-0 mt-0.5" />
                        <span><strong>노션/엑셀 템플릿 자동화</strong>: 수작업 계산을 최소화하여 시간 단축</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="w-4 h-4 text-wave-accent shrink-0 mt-0.5" />
                        <span><strong>목표 중심의 미팅 기획</strong>: 15분 내 핵심 의사결정 완료</span>
                      </li>
                    </ul>
                  </motion.div>

                  <motion.div
                    key="smart-output"
                    initial={{ opacity: 0, x: 10 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -10 }}
                    className="bg-wave-accent/10 border border-wave-accent/40 p-5 rounded-xl space-y-3.5"
                  >
                    <div className="flex items-center gap-2 text-wave-accent font-bold text-sm">
                      <span className="p-1 rounded bg-wave-accent/20 text-wave-accent">🏆</span>
                      <span>스마트 기획 : 최대 아웃풋 (200% 성과)</span>
                    </div>
                    <ul className="space-y-2.5 text-xs text-slate-300">
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="w-4 h-4 text-wave-accent shrink-0 mt-0.5" />
                        <span><strong>베짱이와 개미의 균형</strong>: 효율적인 개미처럼 일하고, 여유 있는 베짱이처럼 평화로운 휴식 시간 확보</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="w-4 h-4 text-wave-accent shrink-0 mt-0.5" />
                        <span><strong>리소스 절약</strong>: 절약된 예산과 에너지로 더 가치 있는 기획에 재투자 가능</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="w-4 h-4 text-wave-accent shrink-0 mt-0.5" />
                        <span><strong>예상치 못한 고성과</strong>: 명확한 길을 갈 때 나오는 최강의 성과</span>
                      </li>
                    </ul>
                  </motion.div>
                </>
              ) : (
                // MANUAL MODE
                <>
                  <motion.div
                    key="manual-input"
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 10 }}
                    className="bg-red-950/10 border border-red-900/30 p-5 rounded-xl space-y-3.5"
                  >
                    <div className="flex items-center gap-2 text-red-400 font-bold text-sm">
                      <span className="p-1 rounded bg-red-950/40 text-red-400">🔨</span>
                      <span>단순 노가다 업무 : 비최적화 인풋 (100% 노동)</span>
                    </div>
                    <ul className="space-y-2.5 text-xs text-slate-400">
                      <li className="flex items-start gap-2">
                        <span className="text-red-400 font-bold mt-0.5">✖</span>
                        <span><strong>정리되지 않은 소통</strong>: 카톡/메일 수십 번 오가며 중복 질문 발생</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-red-400 font-bold mt-0.5">✖</span>
                        <span><strong>반복적인 단순 회의</strong>: 1시간 동안 앉아서 영양가 없는 의견만 나눔</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-red-400 font-bold mt-0.5">✖</span>
                        <span><strong>수동 데이터 기입</strong>: 복사-붙여넣기를 한 땀 한 땀 반복하며 실수 연발</span>
                      </li>
                    </ul>
                  </motion.div>

                  <motion.div
                    key="manual-output"
                    initial={{ opacity: 0, x: 10 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -10 }}
                    className="bg-red-950/10 border border-red-900/30 p-5 rounded-xl space-y-3.5"
                  >
                    <div className="flex items-center gap-2 text-red-400 font-bold text-sm">
                      <span className="p-1 rounded bg-red-950/40 text-red-400">📉</span>
                      <span>단순 노가다 업무 : 저효율 아웃풋 (20% 성과)</span>
                    </div>
                    <ul className="space-y-2.5 text-xs text-slate-400">
                      <li className="flex items-start gap-2">
                        <span className="text-red-400 font-bold mt-0.5">✖</span>
                        <span><strong>번아웃과 야근</strong>: 몸은 고단하고 정작 중요한 기획은 손도 대지 못함</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-red-400 font-bold mt-0.5">✖</span>
                        <span><strong>체계 붕괴</strong>: 마감 시간에 쫓겨 아슬아슬하게 결과물만 급조해 오류 발생</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-red-400 font-bold mt-0.5">✖</span>
                        <span><strong>여유 소멸 (일만 하는 개미)</strong>: 쉴 틈 없이 일만 하여 베짱이처럼 휴식과 창의성을 누릴 여유가 완전히 사라짐</span>
                      </li>
                    </ul>
                  </motion.div>
                </>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </section>
  );
}
