import { useState } from 'react';
import { motion } from 'motion/react';
import { Sparkles, Anchor, ArrowRight, Play, RefreshCw, Layers } from 'lucide-react';

export default function Hero() {
  const [relaxRatio, setRelaxRatio] = useState(60); // Default 60%
  const [useSystem, setUseSystem] = useState(false);

  // Calculate Metrics based on sliders and system toggle
  const creativity = Math.min(100, Math.round(relaxRatio * 1.3));
  const manualOutput = 100 - relaxRatio;
  
  // If system is on, we automate/delegate, which keeps efficiency at 100% and leverages creativity!
  const actualEfficiency = useSystem 
    ? Math.round(100 + (relaxRatio * 0.2)) // smart planning makes relaxation a net positive
    : manualOutput;

  const totalPerformance = Math.round((creativity * actualEfficiency) / 100);

  return (
    <section
      id="hero"
      className="relative min-h-screen flex flex-col justify-center items-center pt-24 pb-16 px-4 overflow-hidden bg-gradient-to-b from-navy-950 via-navy-900 to-ocean-dark text-white"
    >
      {/* Ocean background effects */}
      <div id="hero-bg-overlay" className="absolute inset-0 pointer-events-none opacity-20">
        <div id="hero-bg-glow-1" className="absolute top-1/4 left-1/4 w-96 h-96 bg-ocean-medium rounded-full filter blur-[120px] animate-pulse"></div>
        <div id="hero-bg-glow-2" className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-wave-accent rounded-full filter blur-[120px] animate-pulse" style={{ animationDelay: '2s' }}></div>
      </div>

      {/* Decorative Wave lines at the bottom */}
      <div id="hero-waves" className="absolute bottom-0 left-0 w-full overflow-hidden leading-[0] transform rotate-180 pointer-events-none">
        <svg
          className="relative block w-[calc(100%+1.3px)] h-[80px]"
          data-name="Layer 1"
          xmlns="http://www.w3.org/2000/svg"
          viewBox="0 0 1200 120 vapor"
          preserveAspectRatio="none"
        >
          <path
            d="M321.39,56.44c58-10.79,114.16-30.13,172-41.86,82.39-16.72,168.19-17.73,250.45-.39C823.78,31,906.67,72,985.66,92.83c70.05,18.48,146.53,26.09,214.34,3V120H0V0C26.9,3,56.05,9.79,86.68,17.27c41.3,10.1,84.06,18.52,128.59,21.26A275,275,0,0,0,321.39,56.44Z"
            className="fill-ocean-dark/40"
          ></path>
          <path
            d="M985.66,92.83C906.67,72,823.78,31,743.84,14.19c-82.26-17.34-168.06-16.33-250.45.39-57.84,11.73-114,31.07-172,41.86A269.3,269.3,0,0,1,162.2,67.67C97.17,67.3,42.86,49.2,0,32V120H1200V95.83C1132.19,118.92,1055.71,111.31,985.66,92.83Z"
            className="fill-navy-900"
          ></path>
        </svg>
      </div>

      <div id="hero-content-container" className="relative z-10 w-full max-w-4xl flex flex-col items-center text-center px-4">
        {/* Intro Tag */}
        <motion.div
          id="hero-intro-tag"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full bg-ocean-medium/20 border border-ocean-light/30 text-wave-accent text-xs font-semibold mb-6 shadow-sm shadow-ocean-medium/5"
        >
          <Anchor className="w-3.5 h-3.5 animate-bounce" />
          <span>경영 기획 사무원을 희망하는 고2 학생 박지수</span>
        </motion.div>

        {/* Name and main tagline */}
        <motion.h1
          id="hero-main-title"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.1 }}
          className="text-4xl md:text-6xl font-extrabold font-display tracking-tight leading-tight mb-6"
        >
          가장 효율적인 항로를 찾는 <br />
          <span className="bg-gradient-to-r from-wave-accent via-blue-400 to-ocean-light bg-clip-text text-transparent">
            내비게이터, 박지수입니다.
          </span>
        </motion.h1>

        {/* Sub title */}
        <motion.p
          id="hero-sub-title"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="text-base md:text-xl text-slate-300 max-w-2xl mb-8 leading-relaxed font-sans"
        >
          농땡이 피우는 것을 좋아하지만,
          <span className="block mt-2 text-wave-accent font-bold">
            그렇기에 세상에서 가장 스마트하고 효율적인 기획을 고민합니다.
          </span>
        </motion.p>

        {/* Bio Card */}
        <motion.div
          id="hero-bio-card"
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="w-full max-w-2xl bg-slate-900/60 border border-slate-700/40 rounded-2xl p-6 md:p-8 backdrop-blur-md shadow-xl text-left mb-16 relative"
        >
          <div id="bio-card-indicator" className="absolute top-0 right-8 transform -translate-y-1/2 bg-ocean-medium text-wave-accent text-[10px] uppercase tracking-widest px-3 py-1 rounded-full font-mono border border-ocean-light/20">
            Student ID: 2-Year Jisu
          </div>
          <p className="text-slate-200 text-sm md:text-base leading-relaxed">
            안녕하세요! 불필요한 일에 시간을 쓰기보다, 영리하게 생각하고 빠르게 움직이는 것을 좋아하는 고등학교 2학년 박지수입니다. 저는 일을 효율적으로 끝내고 평화롭게 쉬는 시간을 사랑합니다. <br />
            <span className="block mt-3 text-wave-accent/90">
              이 게으름을 이겨내기 위해 시작된 <strong>'더 편하고, 더 확실하게 일하는 방법'</strong>에 대한 고민이 저를 <strong>경영 기획</strong>이라는 멋진 진로로 이끌었습니다.
            </span>
          </p>
        </motion.div>

        {/* INTERACTIVE COMPONENT: "Relaxation & Efficiency Balance Simulator" */}
        <motion.div
          id="hero-simulator-container"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="w-full max-w-2xl bg-gradient-to-br from-ocean-dark/40 to-navy-900/60 border border-ocean-medium/30 rounded-2xl p-6 md:p-8 backdrop-blur-md shadow-2xl relative"
        >
          <h3 id="simulator-title" className="text-lg font-bold text-slate-100 flex items-center gap-2 mb-4">
            <Sparkles className="w-5 h-5 text-wave-accent animate-pulse" />
            <span>박지수의 '농땡이 & 효율성' 균형 시뮬레이터</span>
          </h3>
          <p className="text-slate-400 text-xs text-left mb-6 leading-relaxed">
            농땡이 피우는 시간(여유)이 창의적인 아이디어 기획력을 극대화하지만, 단순 노동 시간은 감소시킵니다. <br />
            박지수의 <strong>경영 기획 시스템(업무 효율화 & 자동화)</strong>을 활성화하여 기발한 기획력과 완벽한 성과를 동시에 잡아보세요!
          </p>

          <div id="simulator-layout" className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
            {/* Control Panel */}
            <div id="sim-controls" className="space-y-6 text-left">
              {/* Slider */}
              <div id="sim-slider-group">
                <div id="sim-slider-labels" className="flex justify-between items-center mb-2">
                  <span className="text-xs font-semibold text-slate-300">내 하루 농땡이 비중 (여유)</span>
                  <span className="text-sm font-bold text-wave-accent font-mono">{relaxRatio}%</span>
                </div>
                <input
                  id="sim-relax-slider"
                  type="range"
                  min="10"
                  max="90"
                  value={relaxRatio}
                  onChange={(e) => setRelaxRatio(Number(e.target.value))}
                  className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-wave-accent"
                />
                <div id="sim-slider-extremes" className="flex justify-between text-[10px] text-slate-500 mt-1 font-mono">
                  <span>10% (쉴 틈 없음)</span>
                  <span>90% (베짱이 상태)</span>
                </div>
              </div>

              {/* System Toggle */}
              <div id="sim-toggle-group">
                <button
                  id="sim-system-toggle-btn"
                  onClick={() => setUseSystem(!useSystem)}
                  className={`w-full flex items-center justify-between p-3.5 rounded-xl border transition-all duration-300 cursor-pointer ${
                    useSystem
                      ? 'bg-ocean-medium/30 border-wave-accent text-white shadow-md shadow-ocean-medium/20'
                      : 'bg-slate-800/40 border-slate-700/60 text-slate-400'
                  }`}
                >
                  <div id="toggle-label-wrapper" className="flex items-center gap-2.5">
                    <Layers className={`w-4 h-4 ${useSystem ? 'text-wave-accent' : 'text-slate-500'}`} />
                    <div id="toggle-text">
                      <div className="text-xs font-bold text-left">박지수의 경영 기획 시스템</div>
                      <div className="text-[10px] text-slate-400 text-left">업무 자동화 및 스마트 효율 템플릿</div>
                    </div>
                  </div>
                  <div
                    id="toggle-switch-track"
                    className={`w-9 h-5 rounded-full p-0.5 transition-colors duration-300 ${
                      useSystem ? 'bg-wave-accent' : 'bg-slate-700'
                    }`}
                  >
                    <div
                      id="toggle-switch-thumb"
                      className={`w-4 h-4 rounded-full bg-navy-900 transition-transform duration-300 ${
                        useSystem ? 'translate-x-4' : 'translate-x-0'
                      }`}
                    ></div>
                  </div>
                </button>
              </div>
            </div>

            {/* Visualizer Panel */}
            <div id="sim-results" className="bg-slate-900/80 rounded-xl p-5 border border-slate-800 space-y-4">
              <div id="res-creativity" className="space-y-1">
                <div className="flex justify-between text-xs font-medium text-slate-300">
                  <span>💡 창의성 & 기발한 기획력</span>
                  <span className="font-mono text-wave-accent">{creativity}%</span>
                </div>
                <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                  <div
                    className="bg-wave-accent h-full transition-all duration-300"
                    style={{ width: `${creativity}%` }}
                  ></div>
                </div>
              </div>

              <div id="res-efficiency" className="space-y-1">
                <div className="flex justify-between text-xs font-medium text-slate-300">
                  <span>⚙️ 기획 실현 효율성</span>
                  <span className="font-mono text-blue-400">{actualEfficiency}%</span>
                </div>
                <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                  <div
                    className="bg-blue-500 h-full transition-all duration-300"
                    style={{ width: `${Math.min(100, actualEfficiency)}%` }}
                  ></div>
                </div>
              </div>

              <div id="res-total" className="pt-2 border-t border-slate-800 flex justify-between items-center">
                <span className="text-xs font-bold text-slate-200">🏆 최종 업무 성과 (Value)</span>
                <div className="text-right">
                  <div className="text-2xl font-black text-white font-mono animate-pulse">
                    {totalPerformance} <span className="text-xs text-slate-400">pts</span>
                  </div>
                  <div className="text-[10px] text-slate-400">
                    {totalPerformance > 70 ? '🎯 스마트 기획 완성!' : '🔋 여유 또는 시스템 부족'}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Scroll helper */}
        <motion.button
          id="hero-scroll-btn"
          onClick={() => {
            const el = document.getElementById('career');
            if (el) el.scrollIntoView({ behavior: 'smooth' });
          }}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 0.8 }}
          className="mt-12 flex flex-col items-center gap-1.5 text-xs text-slate-400 hover:text-wave-accent transition-colors duration-300 cursor-pointer group"
        >
          <span>진로 목표 들여다보기</span>
          <ArrowRight className="w-4 h-4 transform rotate-90 group-hover:translate-y-1 transition-transform" />
        </motion.button>
      </div>
    </section>
  );
}
