import { useState, useEffect } from 'react';
import Navigation from './components/Navigation';
import Hero from './components/Hero';
import CareerGoal from './components/CareerGoal';
import Activities from './components/Activities';
import Strengths from './components/Strengths';
import Weakness from './components/Weakness';
import Guestbook from './components/Guestbook';
import { ArrowUp, Anchor } from 'lucide-react';

export default function App() {
  const [activeSection, setActiveSection] = useState('hero');
  const [showScrollTop, setShowScrollTop] = useState(false);

  // Monitor active section using Intersection Observer
  useEffect(() => {
    const sections = ['hero', 'career', 'activities', 'strengths', 'weakness', 'guestbook'];
    
    const observerOptions = {
      root: null,
      rootMargin: '-30% 0px -40% 0px', // Trigger when section occupies the main viewing area
      threshold: 0,
    };

    const handleIntersection = (entries: IntersectionObserverEntry[]) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          setActiveSection(entry.target.id);
        }
      });
    };

    const observer = new IntersectionObserver(handleIntersection, observerOptions);

    sections.forEach((id) => {
      const element = document.getElementById(id);
      if (element) observer.observe(element);
    });

    return () => {
      sections.forEach((id) => {
        const element = document.getElementById(id);
        if (element) observer.unobserve(element);
      });
    };
  }, []);

  // Monitor scroll for ScrollToTop button
  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 300);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div id="app-root-container" className="min-h-screen bg-navy-950 font-sans text-slate-100 selection:bg-wave-accent selection:text-navy-950">
      {/* Floating Header Navigation */}
      <Navigation activeSection={activeSection} />

      {/* Main Content Sections */}
      <main id="main-content">
        <Hero />
        <CareerGoal />
        <Activities />
        <Strengths />
        <Weakness />
        <Guestbook />
      </main>

      {/* Beautiful Footer */}
      <footer id="footer-container" className="bg-slate-950 border-t border-slate-900 py-12 px-4 text-center text-xs text-slate-500 relative">
        <div id="footer-inner" className="max-w-4xl mx-auto space-y-4">
          <div id="footer-decor-row" className="flex items-center justify-center gap-2 text-slate-400">
            <Anchor className="w-4 h-4 text-wave-accent animate-pulse" />
            <span className="font-display font-bold tracking-tight text-slate-300">박지수 진로 포트폴리오</span>
          </div>
          <p className="max-w-md mx-auto leading-relaxed">
            "가장 효율적인 항로를 찾는 내비게이터." 게으름을 극복하기 위해 영리한 시스템 기획을 수립하는 고등학교 2학년 박지수의 꿈을 응원해 주셔서 감사합니다.
          </p>
          <div id="footer-copyright" className="pt-4 border-t border-slate-900 flex flex-col sm:flex-row justify-between items-center gap-2 font-mono text-[10px]">
            <span>© 2026 Park Jisu. All Rights Reserved.</span>
            <span className="text-wave-accent">Designed with Navy & Deep Blue Sea Vibe</span>
          </div>
        </div>
      </footer>

      {/* Floating ScrollToTop Button */}
      <button
        id="scroll-to-top-btn"
        onClick={scrollToTop}
        className={`fixed bottom-6 right-6 p-3 rounded-full bg-ocean-medium hover:bg-wave-accent text-white hover:text-navy-950 shadow-lg border border-ocean-light/20 transition-all duration-300 z-40 cursor-pointer ${
          showScrollTop ? 'opacity-100 scale-100 translate-y-0' : 'opacity-0 scale-75 translate-y-4 pointer-events-none'
        }`}
        title="맨 위로 이동"
      >
        <ArrowUp className="w-5 h-5" />
      </button>
    </div>
  );
}
