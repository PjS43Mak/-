import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Briefcase, Calendar, Star, Users, CheckCircle, Tag, ChevronDown, BookOpen } from 'lucide-react';
import { Activity } from '../types';

export default function Activities() {
  const [selectedCategory, setSelectedCategory] = useState<'all' | 'school' | 'club' | 'self'>('all');
  const [expandedId, setExpandedId] = useState<string | null>('activity-1');

  const activities: Activity[] = [
    {
      id: 'activity-1',
      title: '학급 축제 기획 및 운영 효율화',
      period: '고등학교 2학년 (학급 부회장 활동)',
      role: '학급 부스 운영 총괄 기획자',
      summary: '동선 배치와 조별 분담 시스템을 최적화하여 축제 준비 시간을 절반 이상 단축하고, 모두에게 휴식(농땡이) 시간을 선물한 고효율 기획사례',
      description: [
        '기존 축제 준비 시 발생하는 역할 중복과 불필요한 대기 인원 문제를 데이터화하여 4개 전담 조직으로 개편',
        '각 부서원의 강점(미적 능력, 기획력, 친화력)에 맞춰 핵심 Task를 할당하고 직교화된 30분 마일스톤 설계',
        '원활한 자재 수급을 위해 학교 내 상점 동선을 사전에 파악하여 구매 횟수를 기존 5회에서 1회로 통합',
        '그 결과 타 학급 대비 준비 시간 2시간을 조기 확보하여 학급 부원 전원이 축제 시작 전에 여유롭게 쉬는 평화를 달성'
      ],
      tags: ['조직 설계', '동선 최적화', '자원 관리', '휴식 시간 확보'],
      category: 'school'
    },
    {
      id: 'activity-2',
      title: '경영·창업 동아리 \'시너지(Synergy)\' 마켓 분석',
      period: '고등학교 1~2학년',
      role: '마켓 데이터 수집 및 수요 기획 팀장',
      summary: '모바일 설문 기반의 빠른 타겟 분석을 통해 친환경 굿즈 창업 프로젝트의 리스크를 줄이고 최대의 성과를 거둔 실전 분석사례',
      description: [
        '전교생 100명을 대상으로 빠른 모바일 서베이를 운영하여 청소년 구매 가능 가격대(3,000원 이하)와 선호 아이템 전수 조사',
        '수작업 설문 정리가 아닌 구글 시트 수식 자동화 분석기를 구축하여 단 1시간 만에 선호 트렌드 파악 완료',
        '재고 최소화를 위해 친환경 텀블러 스트랩을 메인 타겟으로 좁혀 공급망을 기획하고 불필요한 디자인 요소를 전면 배제',
        '분석에 의거한 영리한 기획을 통해 불필요한 제작 비용을 절감하여 예산 대비 마일스톤 성취 및 기획 오차 5% 미만 달성'
      ],
      tags: ['수요 예측', '설문 데이터 분석', '공급망 리스크 헤징', '제품 타겟팅'],
      category: 'club'
    },
    {
      id: 'activity-3',
      title: '나만의 콤팩트 시간 관리 플래너 제작 및 실험',
      period: '고등학교 2학년 (개인 프로젝트)',
      role: '시간 관리 툴 메이커 및 실험 피험자',
      summary: '벼락치기 습관과 게으름을 고치기 위해 \'하루 딱 3개 태스크 완수\'의 초압축 노션 스케줄러를 개발하여 학습 효율을 30% 끌어올린 자가 경영사례',
      description: [
        '빽빽하고 지루한 고전 계획 플래너의 단점을 극복하기 위해, 오직 그날의 핵심 골칫거리 3가지만 적고 즉시 끝내는 템플릿 개발',
        '노션(Notion)의 수식 기능과 엑셀 분석기를 활용하여 매주 나의 학습 시간 대비 완수 확률을 실시간 게이지로 피드백하도록 연동',
        '목표를 미루기 쉬운 게으른 체질에 맞추어 \'쉬는 시간 1.5배 보너스 제공 법칙\'을 설계하여 스스로가 계획을 따르는 강력한 유인책 창출',
        '본 기획 시스템을 기말고사 기간에 스스로 시험하여 하루 전체 공부 몰입도 향상 및 시험 기간 평균 효율 30% 이상 증가 입증'
      ],
      tags: ['노션 수식', '자가 생산성 측정', '미니멀리즘 계획', '행동 경제학 적용'],
      category: 'self'
    }
  ];

  const filteredActivities = selectedCategory === 'all' 
    ? activities 
    : activities.filter(a => a.category === selectedCategory);

  const toggleExpand = (id: string) => {
    setExpandedId(expandedId === id ? null : id);
  };

  return (
    <section
      id="activities"
      className="py-24 px-4 bg-navy-950 text-white relative"
    >
      <div id="activities-content-wrapper" className="max-w-4xl mx-auto">
        {/* Section Header */}
        <div id="activities-header" className="text-center mb-16">
          <h2 className="text-xs font-mono uppercase tracking-widest text-wave-accent mb-2 flex items-center justify-center gap-2">
            <Briefcase className="w-4 h-4" /> Portfolios & Activities
          </h2>
          <h3 className="text-3xl md:text-4xl font-extrabold font-display tracking-tight text-white">
            진로 핵심 활동 3가지
          </h3>
          <p className="mt-4 text-slate-400 max-w-2xl mx-auto text-sm md:text-base">
            불필요한 노력을 없애고 효율적인 구조를 기획하는 일, 학업과 동아리 그리고 제 생활 속에서 직접 실천해 온 소중한 기록들입니다.
          </p>
        </div>

        {/* Categories Tab Selector */}
        <div id="activities-category-tabs" className="flex justify-center gap-2 mb-12 flex-wrap">
          {(['all', 'school', 'club', 'self'] as const).map((cat) => {
            const labels = { all: '전체 보기', school: '🏫 학급 부회장 활동', club: '🤝 창업 동아리', self: '📅 자가 관리 실험' };
            const isActive = selectedCategory === cat;
            return (
              <button
                key={cat}
                id={`cat-tab-${cat}`}
                onClick={() => setSelectedCategory(cat)}
                className={`px-4 py-2 rounded-full text-xs font-semibold transition-all duration-300 cursor-pointer ${
                  isActive
                    ? 'bg-ocean-medium text-white shadow-md shadow-ocean-medium/20 scale-105 border border-ocean-light/30'
                    : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white hover:bg-slate-800/50'
                }`}
              >
                {labels[cat]}
              </button>
            );
          })}
        </div>

        {/* Activities List */}
        <div id="activities-list-container" className="space-y-6">
          <AnimatePresence mode="popLayout">
            {filteredActivities.map((act, index) => {
              const isExpanded = expandedId === act.id;
              return (
                <motion.div
                  key={act.id}
                  id={`activity-card-${act.id}`}
                  layout
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  className={`bg-slate-900/60 border rounded-2xl overflow-hidden transition-all duration-300 backdrop-blur-sm ${
                    isExpanded 
                      ? 'border-wave-accent shadow-lg shadow-wave-accent/5' 
                      : 'border-slate-800 hover:border-slate-700 hover:bg-slate-900/80'
                  }`}
                >
                  {/* Card Header (clickable to toggle) */}
                  <div
                    id={`activity-header-${act.id}`}
                    onClick={() => toggleExpand(act.id)}
                    className="p-6 md:p-8 flex items-start justify-between gap-4 cursor-pointer select-none"
                  >
                    <div id="card-header-left" className="space-y-2 text-left">
                      <div id="header-badge-row" className="flex items-center gap-2 flex-wrap">
                        <span className="inline-flex items-center gap-1 text-[10px] font-mono font-bold uppercase tracking-wider text-wave-accent bg-wave-accent/10 px-2.5 py-1 rounded-full border border-wave-accent/20">
                          <Calendar className="w-3 h-3" /> {act.period}
                        </span>
                        <span className="text-[10px] font-bold text-slate-400 bg-slate-800/80 px-2.5 py-1 rounded-full border border-slate-700/50">
                          {act.role}
                        </span>
                      </div>
                      <h4 className="text-lg md:text-xl font-bold text-white group-hover:text-wave-accent transition-colors">
                        {act.title}
                      </h4>
                      <p className="text-xs md:text-sm text-slate-400 leading-relaxed max-w-3xl">
                        {act.summary}
                      </p>
                    </div>

                    <button
                      id={`expand-btn-${act.id}`}
                      className={`p-2 rounded-full border bg-slate-950/40 transition-transform duration-300 shrink-0 cursor-pointer ${
                        isExpanded ? 'border-wave-accent text-wave-accent rotate-180' : 'border-slate-800 text-slate-500'
                      }`}
                    >
                      <ChevronDown className="w-4 h-4" />
                    </button>
                  </div>

                  {/* Expanded Content */}
                  <AnimatePresence initial={false}>
                    {isExpanded && (
                      <motion.div
                        id={`activity-details-${act.id}`}
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.3 }}
                        className="overflow-hidden border-t border-slate-800 bg-slate-950/30"
                      >
                        <div id="details-inner" className="p-6 md:p-8 space-y-6 text-left">
                          <div id="details-action-steps" className="space-y-4">
                            <h5 className="text-xs font-bold text-wave-accent uppercase tracking-widest flex items-center gap-1.5">
                              <BookOpen className="w-3.5 h-3.5" /> 상세 기획 및 성과 지표
                            </h5>
                            <div id="steps-list" className="space-y-3 pl-1">
                              {act.description.map((desc, dIdx) => (
                                <div key={dIdx} className="flex items-start gap-3 text-sm text-slate-300">
                                  <span className="flex items-center justify-center w-5 h-5 rounded-full bg-ocean-medium/20 text-wave-accent text-[11px] font-mono font-bold shrink-0 mt-0.5">
                                    {dIdx + 1}
                                  </span>
                                  <p className="leading-relaxed">{desc}</p>
                                </div>
                              ))}
                            </div>
                          </div>

                          {/* Tags row */}
                          <div id="details-tags-row" className="flex items-center gap-2 flex-wrap pt-4 border-t border-slate-800/40">
                            <Tag className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                            {act.tags.map((tag) => (
                              <span
                                key={tag}
                                className="text-[10px] font-medium text-slate-400 bg-slate-900 border border-slate-800 px-2 py-0.5 rounded"
                              >
                                #{tag}
                              </span>
                            ))}
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </motion.div>
              );
            })}
          </AnimatePresence>
        </div>
      </div>
    </section>
  );
}
