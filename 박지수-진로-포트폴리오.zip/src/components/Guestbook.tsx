import { useState, useEffect, FormEvent, MouseEvent } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MessageSquare, Send, User, Badge, Bookmark, Trash2, Heart, HelpCircle, Eye } from 'lucide-react';
import { GuestbookMessage } from '../types';

export default function Guestbook() {
  const [messages, setMessages] = useState<GuestbookMessage[]>([]);
  const [name, setName] = useState('');
  const [message, setMessage] = useState('');
  const [role, setRole] = useState('지나가는 항해사');
  const [selectedLetter, setSelectedLetter] = useState<GuestbookMessage | null>(null);

  const roles = [
    '지나가는 항해사',
    '🏫 학교 친구',
    '👥 창업 동아리원',
    '💼 미래의 고용주',
    '💡 인생 멘토',
  ];

  // Load and pre-load default messages
  useEffect(() => {
    const saved = localStorage.getItem('jisu_portfolio_guestbook');
    if (saved) {
      setMessages(JSON.parse(saved));
    } else {
      const defaultMsgs: GuestbookMessage[] = [
        {
          id: 'default-1',
          name: '김도윤',
          role: '🏫 학교 친구',
          message: '축제 때 부회장 기획 덕분에 다른 반 축제물품 다 부수고 타코야끼 조기에 구워먹고 꿀잠잤음... 진짜 기획 동선 하나는 신의 영역이다. 인정한다 박지수!',
          timestamp: '2026.07.07 15:42'
        },
        {
          id: 'default-2',
          name: '동아리 멘토 선배',
          role: '💡 인생 멘토',
          message: '시너지 창업 마켓 분석 리포트 한 시간 만에 구글 시트로 자동 수식 뽑아서 피드백하는 것 보고 깜짝 놀랐습니다. 현직 주니어 기획자보다 빠르고 영리해요. 파이팅!',
          timestamp: '2026.07.06 19:10'
        },
        {
          id: 'default-3',
          name: '고2 담임 선생님',
          role: '🏫 학교 친구',
          message: '게으름을 효율성 극대화의 도구로 비틀어 쓰는 영리함에 박수를 보낸다, 지수야! 진심 어린 자기 성찰이 돋보이는구나. 다음 주 교실 자리 배치도 최적화 기획서 기대할게! ^^',
          timestamp: '2026.07.05 11:05'
        }
      ];
      setMessages(defaultMsgs);
      localStorage.setItem('jisu_portfolio_guestbook', JSON.stringify(defaultMsgs));
    }
  }, []);

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !message.trim()) return;

    const now = new Date();
    const formattedDate = `${now.getFullYear()}.${String(now.getMonth() + 1).padStart(2, '0')}.${String(
      now.getDate()
    ).padStart(2, '0')} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;

    const newMessage: GuestbookMessage = {
      id: Math.random().toString(),
      name: name.trim(),
      message: message.trim(),
      role,
      timestamp: formattedDate,
    };

    const updated = [newMessage, ...messages];
    setMessages(updated);
    localStorage.setItem('jisu_portfolio_guestbook', JSON.stringify(updated));

    // Reset fields
    setName('');
    setMessage('');
  };

  const handleDelete = (id: string, e: MouseEvent) => {
    e.stopPropagation(); // prevent expanding card
    const updated = messages.filter((m) => m.id !== id);
    setMessages(updated);
    localStorage.setItem('jisu_portfolio_guestbook', JSON.stringify(updated));
    if (selectedLetter?.id === id) {
      setSelectedLetter(null);
    }
  };

  return (
    <section
      id="guestbook"
      className="py-24 px-4 bg-navy-950 text-white relative"
    >
      <div id="guestbook-content-wrapper" className="max-w-4xl mx-auto">
        {/* Section Header */}
        <div id="guestbook-header" className="text-center mb-16">
          <h2 className="text-xs font-mono uppercase tracking-widest text-wave-accent mb-2 flex items-center justify-center gap-2">
            <MessageSquare className="w-4 h-4" /> Guestbook
          </h2>
          <h3 className="text-3xl md:text-4xl font-extrabold font-display tracking-tight text-white">
            유리병 편지 : 격려의 메세지
          </h3>
          <p className="mt-4 text-slate-400 max-w-2xl mx-auto text-sm md:text-base">
            항해 중인 박지수 학생에게 조언이나 격려의 한마디를 남겨주세요. 
            남겨주신 한마디 한마디는 깊은 바다 속 등대처럼 제 항로를 밝히는 소중한 불빛이 됩니다.
          </p>
        </div>

        <div id="guestbook-layout" className="grid grid-cols-1 md:grid-cols-12 gap-8 items-start">
          {/* Form Panel */}
          <div id="guestbook-form-panel" className="md:col-span-5 bg-slate-900/60 border border-slate-800 rounded-2xl p-6 backdrop-blur-sm">
            <h4 className="text-base font-bold text-slate-200 flex items-center gap-2 mb-4">
              <span>✍️ 병 편지 띄우기</span>
            </h4>
            <form id="bottle-message-form" onSubmit={handleSubmit} className="space-y-4">
              {/* Name Input */}
              <div id="form-group-name" className="space-y-1.5 text-left">
                <label className="text-xs font-semibold text-slate-400">당신의 이름</label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                  <input
                    id="input-guest-name"
                    type="text"
                    required
                    placeholder="이름이나 닉네임"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full pl-10 pr-4 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-600 focus:border-wave-accent focus:outline-none transition-colors"
                  />
                </div>
              </div>

              {/* Role Select */}
              <div id="form-group-role" className="space-y-1.5 text-left">
                <label className="text-xs font-semibold text-slate-400">나와의 관계</label>
                <select
                  id="select-guest-role"
                  value={role}
                  onChange={(e) => setRole(e.target.value)}
                  className="w-full px-3 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-300 focus:border-wave-accent focus:outline-none transition-colors"
                >
                  {roles.map((r) => (
                    <option key={r} value={r} className="bg-navy-950">
                      {r}
                    </option>
                  ))}
                </select>
              </div>

              {/* Message Input */}
              <div id="form-group-msg" className="space-y-1.5 text-left">
                <label className="text-xs font-semibold text-slate-400">따뜻한 한마디</label>
                <textarea
                  id="textarea-guest-msg"
                  required
                  rows={4}
                  placeholder="지수에게 띄울 응원의 메시지를 적어주세요!"
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  className="w-full px-3 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-600 focus:border-wave-accent focus:outline-none transition-colors resize-none"
                />
              </div>

              {/* Submit Button */}
              <button
                id="submit-message-btn"
                type="submit"
                className="w-full py-3 bg-ocean-medium hover:bg-ocean-light text-white text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 transition-colors cursor-pointer shadow-md shadow-ocean-medium/10"
              >
                <Send className="w-3.5 h-3.5" />
                <span>유리병 편지 바다로 띄우기</span>
              </button>
            </form>
          </div>

          {/* Letters Grid */}
          <div id="guestbook-list-panel" className="md:col-span-7 space-y-4">
            <div className="flex justify-between items-center mb-2">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">바다에 떠다니는 편지함 ({messages.length})</span>
              <span className="text-[10px] text-slate-500 flex items-center gap-1">
                <Eye className="w-3 h-3 text-wave-accent" /> 편지를 클릭하면 펼쳐집니다
              </span>
            </div>

            <div id="bottled-messages-grid" className="grid grid-cols-2 gap-4 max-h-[460px] overflow-y-auto pr-2">
              {messages.map((msg) => (
                <div
                  key={msg.id}
                  id={`bottle-letter-card-${msg.id}`}
                  onClick={() => setSelectedLetter(msg)}
                  className="bg-slate-900/40 border border-slate-800 hover:border-wave-accent/40 rounded-xl p-4 text-left transition-all duration-300 cursor-pointer relative group flex flex-col justify-between hover:bg-slate-900/80 hover:translate-y-[-2px]"
                >
                  <div id="card-inner-top" className="space-y-1.5">
                    <div className="flex items-center justify-between gap-1">
                      <span className="text-[10px] text-wave-accent font-bold bg-wave-accent/10 px-2 py-0.5 rounded border border-wave-accent/20">
                        {msg.role || '항해사'}
                      </span>
                      {msg.id.startsWith('default') ? null : (
                        <button
                          id={`delete-msg-btn-${msg.id}`}
                          onClick={(e) => handleDelete(msg.id, e)}
                          className="opacity-0 group-hover:opacity-100 p-1 text-slate-600 hover:text-red-400 transition-opacity cursor-pointer rounded"
                          title="삭제하기"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                    <p className="text-xs text-slate-300 font-medium line-clamp-3">
                      "{msg.message}"
                    </p>
                  </div>

                  <div id="card-inner-bottom" className="flex items-center justify-between pt-3 border-t border-slate-800/40 mt-3 text-[10px] text-slate-500">
                    <span className="font-bold text-slate-400">{msg.name}</span>
                    <span className="font-mono">{msg.timestamp.split(' ')[0]}</span>
                  </div>

                  {/* Bottle Icon decoration */}
                  <div className="absolute right-2 top-2 text-xl opacity-20 group-hover:opacity-80 transition-opacity pointer-events-none">
                    🍾
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* DIALOG POPUP: Read Expanded Letter */}
        <AnimatePresence>
          {selectedLetter && (
            <div
              id="letter-popup-overlay"
              onClick={() => setSelectedLetter(null)}
              className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 cursor-zoom-out"
            >
              <motion.div
                id="letter-popup-modal"
                onClick={(e) => e.stopPropagation()} // prevent closing
                initial={{ opacity: 0, scale: 0.95, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95, y: 20 }}
                className="w-full max-w-md bg-gradient-to-br from-slate-900 to-navy-950 border border-wave-accent/30 rounded-3xl p-6 md:p-8 relative shadow-2xl cursor-default"
              >
                {/* Floating Bottle graphics */}
                <div className="absolute -top-12 left-1/2 -translate-x-1/2 text-5xl">
                  🍾
                </div>

                <div id="modal-content-wrapper" className="space-y-4 pt-4 text-left">
                  <div id="modal-role-badge" className="flex justify-between items-center">
                    <span className="text-xs font-bold text-wave-accent bg-wave-accent/10 px-3 py-1 rounded-full border border-wave-accent/20">
                      {selectedLetter.role || '지나가는 항해사'}
                    </span>
                    <span className="text-[10px] font-mono text-slate-500">{selectedLetter.timestamp}</span>
                  </div>

                  <div id="modal-message-body" className="bg-slate-950/60 p-5 rounded-2xl border border-slate-800/80 relative">
                    <p className="text-sm text-slate-200 leading-relaxed italic whitespace-pre-wrap">
                      "{selectedLetter.message}"
                    </p>
                    <div className="absolute bottom-2 right-4 text-xs font-bold text-wave-accent/40 font-mono">
                      ✉️ Port Letter
                    </div>
                  </div>

                  <div id="modal-sender-row" className="flex items-center justify-between">
                    <span className="text-xs text-slate-400">보낸 사람: <strong className="text-slate-200 font-bold text-sm">{selectedLetter.name}</strong>님</span>
                    <button
                      id="close-modal-btn"
                      onClick={() => setSelectedLetter(null)}
                      className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold rounded-xl transition-colors cursor-pointer"
                    >
                      닫기
                    </button>
                  </div>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>
      </div>
    </section>
  );
}
