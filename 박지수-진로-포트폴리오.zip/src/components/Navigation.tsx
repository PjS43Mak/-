import { useState, useEffect } from 'react';
import { Compass, Goal, Briefcase, Zap, AlertTriangle, MessageSquare } from 'lucide-react';

interface NavigationProps {
  activeSection: string;
}

export default function Navigation({ activeSection }: NavigationProps) {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { id: 'hero', label: '소개', icon: Compass },
    { id: 'career', label: '목표', icon: Goal },
    { id: 'activities', label: '활동', icon: Briefcase },
    { id: 'strengths', label: '강점', icon: Zap },
    { id: 'weakness', label: '단점 극복', icon: AlertTriangle },
    { id: 'guestbook', label: '방명록', icon: MessageSquare },
  ];

  const handleScrollTo = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <header
      id="main-nav-header"
      className={`fixed top-4 left-1/2 -translate-x-1/2 z-50 transition-all duration-300 w-full max-w-2xl px-4`}
    >
      <nav
        id="main-nav-container"
        className={`flex items-center justify-around py-3 px-6 rounded-full border shadow-lg backdrop-blur-md transition-all duration-300 ${
          isScrolled
            ? 'bg-navy-950/80 border-ocean-medium/40 shadow-ocean-medium/10'
            : 'bg-navy-900/40 border-slate-700/30'
        }`}
      >
        {/* LOGO */}
        <button
          id="nav-logo-btn"
          onClick={() => handleScrollTo('hero')}
          className="hidden sm:flex items-center gap-2 text-wave-accent font-bold font-display tracking-tight hover:text-white transition-colors mr-2 cursor-pointer"
        >
          <span className="text-xl">🌊</span>
          <span className="text-sm">JISU.P</span>
        </button>

        {/* NAV ITEMS */}
        <div id="nav-items-wrapper" className="flex items-center gap-1 sm:gap-2">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeSection === item.id;
            return (
              <button
                key={item.id}
                id={`nav-item-${item.id}`}
                onClick={() => handleScrollTo(item.id)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium transition-all duration-300 cursor-pointer ${
                  isActive
                    ? 'bg-ocean-medium text-white shadow-md shadow-ocean-medium/30 scale-105'
                    : 'text-slate-300 hover:text-white hover:bg-slate-800/50'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-wave-accent' : 'text-slate-400'}`} />
                <span className="hidden md:inline">{item.label}</span>
              </button>
            );
          })}
        </div>
      </nav>
    </header>
  );
}
