import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Zap, Play, RotateCcw, AlertOctagon, HeartCrack, Award } from 'lucide-react';
import { Crisis } from '../types';

export default function Strengths() {
  const [gameState, setGameState] = useState<'idle' | 'countdown' | 'playing' | 'result'>('idle');
  const [countdown, setCountdown] = useState(3);
  const [crises, setCrises] = useState<Crisis[]>([]);
  const [clickTimes, setClickTimes] = useState<number[]>([]);
  const [currentCrisisIndex, setCurrentCrisisIndex] = useState(0);
  const [averageTime, setAverageTime] = useState(0);
  const [highScore, setHighScore] = useState<number | null>(null);

  const containerRef = useRef<HTMLDivElement>(null);
  const crisisStartTime = useRef<number>(0);

  const crisisLabels = [
    '⚠️ 축제 예산 부족!',
    '🛑 스케줄 꼬임!',
    '💥 부재원 지각!',
    '🌪️ 동선 대공황!',
    '🌊 소나기 돌발발생!',
    '📢 설문 조사 거부!',
    '📈 급격한 원가 상승!',
    '📉 예상치 못한 비난!',
  ];

  const colors = [
    'border-red-400 text-red-300 bg-red-950/40',
    'border-amber-400 text-amber-300 bg-amber-950/40',
    'border-orange-400 text-orange-300 bg-orange-950/40',
    'border-yellow-400 text-yellow-300 bg-yellow-950/40',
  ];

  // Load high score from local storage
  useEffect(() => {
    const saved = localStorage.getItem('jisu_strength_highscore');
    if (saved) {
      setHighScore(Number(saved));
    }
  }, []);

  const startTest = () => {
    setGameState('countdown');
    setCountdown(3);
    setClickTimes([]);
    setCurrentCrisisIndex(0);
  };

  // Countdown handler
  useEffect(() => {
    if (gameState !== 'countdown') return;

    if (countdown > 0) {
      const timer = setTimeout(() => setCountdown(countdown - 1), 1000);
      return () => clearTimeout(timer);
    } else {
      setGameState('playing');
      spawnCrisis();
    }
  }, [gameState, countdown]);

  const spawnCrisis = () => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    
    // Margins to prevent overflow
    const margin = 80;
    const x = Math.max(margin, Math.random() * (rect.width - margin * 2));
    const y = Math.max(margin, Math.random() * (rect.height - margin * 2));
    
    const size = Math.floor(Math.random() * 40) + 140; // width between 140 and 180
    const color = colors[Math.floor(Math.random() * colors.length)];
    const title = crisisLabels[Math.floor(Math.random() * crisisLabels.length)];

    const newCrisis: Crisis = {
      id: Math.random().toString(),
      title,
      x,
      y,
      size,
      color,
    };

    setCrises([newCrisis]);
    crisisStartTime.current = Date.now();
  };

  const handleCrisisClick = (id: string) => {
    const reactionTime = Date.now() - crisisStartTime.current;
    const updatedClickTimes = [...clickTimes, reactionTime];
    setClickTimes(updatedClickTimes);

    // Next round
    const nextIndex = currentCrisisIndex + 1;
    if (nextIndex < 5) {
      setCurrentCrisisIndex(nextIndex);
      spawnCrisis();
    } else {
      // Calculate results
      const total = updatedClickTimes.reduce((a, b) => a + b, 0);
      const avg = Math.round(total / 5);
      setAverageTime(avg);

      // Save high score if lower (faster)
      if (!highScore || avg < highScore) {
        setHighScore(avg);
        localStorage.setItem('jisu_strength_highscore', avg.toString());
      }

      setGameState('result');
      setCrises([]);
    }
  };

  const getResultRating = (avg: number) => {
    if (avg < 250) {
      return {
        title: '신비로운 번개 돌고래급 순발력',
        desc: '박지수 학생의 순발력과 필적하는 위기대응 초천재! 파도의 정점에 서서 모든 돌발변수를 제어하는 초인적인 속도를 가졌습니다.',
        badge: '⚡ S등급',
        color: 'text-wave-accent'
      };
    } else if (avg < 450) {
      return {
        title: '지능형 위기 돌파 항해사 (박지수 클래스)',
        desc: '돌발 상황에 신속히 차선책을 마련해 대처하고 유유히 자러 가는 스마트 기획자의 자질을 백분 갖췄습니다. 실무에 강한 순발력!',
        badge: '🌊 A등급',
        color: 'text-emerald-400'
      };
    } else if (avg < 750) {
      return {
        title: '신중한 안전 지향형 거북이',
        desc: '느리지만 확실하게 상황을 타개하는 스타일입니다. 기획 시 리스크 대비책을 꼼꼼하게 마련해야 안전하게 휴식을 지킬 수 있습니다.',
        badge: '🐢 B등급',
        color: 'text-amber-400'
      };
    } else {
      return {
        title: '물방울에 가로막힌 침몰함',
        desc: '위기가 오면 순간 얼어붙는 군요! 혼자 해결하려다간 야근에 휩쓸립니다. 지수 학생의 "스마트 경영 기획 시스템" 지원이 급히 필요합니다.',
        badge: '💤 C등급',
        color: 'text-red-400'
      };
    }
  };

  const currentRating = gameState === 'result' ? getResultRating(averageTime) : null;

  return (
    <section
      id="strengths"
      className="py-24 px-4 bg-gradient-to-b from-navy-950 via-ocean-dark to-navy-900 text-white relative"
    >
      <div id="strengths-content-wrapper" className="max-w-4xl mx-auto">
        {/* Section Header */}
        <div id="strengths-header" className="text-center mb-12">
          <h2 className="text-xs font-mono uppercase tracking-widest text-wave-accent mb-2 flex items-center justify-center gap-2">
            <Zap className="w-4 h-4 animate-pulse" /> My Strength
          </h2>
          <h3 className="text-3xl md:text-4xl font-extrabold font-display tracking-tight text-white">
            나의 강점 : 예기치 못한 파도를 넘는 '순발력'
          </h3>
          <p className="mt-4 text-slate-400 max-w-2xl mx-auto text-sm md:text-base">
            경영 기획에서는 예상치 못한 돌발 변수가 불쑥 찾아옵니다. 계획이 비틀거릴 때 주저하지 않고, 
            <strong className="text-wave-accent font-semibold"> 그 순간 직관적으로 가장 빠른 차선책</strong>을 찾아내는 것이 저의 무기입니다.
          </p>
        </div>

        {/* INTERACTIVE COMPONENT: Crisis Reflex Game */}
        <div id="reflex-game-container" className="bg-slate-900/60 border border-slate-800 rounded-3xl p-6 md:p-8 backdrop-blur-sm relative overflow-hidden">
          <div id="reflex-header-grid" className="flex flex-col sm:flex-row justify-between items-center gap-4 mb-6 pb-6 border-b border-slate-800">
            <div id="reflex-info-text" className="text-left">
              <h4 className="text-base font-bold text-slate-200 flex items-center gap-2">
                <AlertOctagon className="w-4.5 h-4.5 text-wave-accent" />
                <span>박지수의 돌발 위기대응 순발력 테스트</span>
              </h4>
              <p className="text-xs text-slate-400 mt-1">
                화면에 불쑥 나타나는 빨간 위기 버블들을 총 5회 빠르게 파괴하세요! 반응 속도 평균을 측정합니다.
              </p>
            </div>
            
            {/* Stats */}
            <div id="reflex-scores" className="flex gap-4 font-mono text-xs">
              <div id="reflex-best" className="bg-slate-950/60 border border-slate-800 px-3.5 py-1.5 rounded-xl">
                <span className="text-slate-500">BEST RX : </span>
                <span className="text-wave-accent font-bold">{highScore ? `${highScore}ms` : '없음'}</span>
              </div>
            </div>
          </div>

          {/* Test Canvas Frame */}
          <div
            id="reflex-test-canvas"
            ref={containerRef}
            className="w-full h-80 md:h-96 bg-slate-950/80 rounded-2xl border border-slate-800/80 relative flex items-center justify-center overflow-hidden shadow-inner cursor-crosshair"
          >
            {/* Grid Pattern Background to feel techy */}
            <div className="absolute inset-0 bg-[linear-gradient(to_right,#0f172a_1px,transparent_1px),linear-gradient(to_bottom,#0f172a_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_50%,#000_70%,transparent_100%)] opacity-30"></div>

            <AnimatePresence mode="wait">
              {/* IDLE STATE */}
              {gameState === 'idle' && (
                <motion.div
                  key="idle"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="flex flex-col items-center text-center p-4 relative z-10"
                >
                  <div className="w-16 h-16 rounded-full bg-wave-accent/10 border border-wave-accent/30 flex items-center justify-center mb-4">
                    <Zap className="w-8 h-8 text-wave-accent animate-pulse" />
                  </div>
                  <h5 className="text-lg font-bold text-slate-200">위기가 덮치기 일보직전!</h5>
                  <p className="text-xs text-slate-500 max-w-sm mt-1.5 mb-6">
                    시작 버튼을 누르면 화면 곳곳에 위기 버블이 빠르게 번갈아 생겨납니다. 마우스로 조준하여 광클하세요!
                  </p>
                  <button
                    id="start-reflex-btn"
                    onClick={startTest}
                    className="flex items-center gap-2 px-6 py-3 bg-wave-accent text-navy-950 font-bold rounded-xl shadow-lg hover:bg-white hover:scale-105 transition-all duration-300 cursor-pointer"
                  >
                    <Play className="w-4 h-4 fill-navy-950" />
                    <span>순발력 측정 시작</span>
                  </button>
                </motion.div>
              )}

              {/* COUNTDOWN STATE */}
              {gameState === 'countdown' && (
                <motion.div
                  key="countdown"
                  initial={{ opacity: 0, scale: 0.5 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 1.5 }}
                  transition={{ duration: 0.3 }}
                  className="text-6xl md:text-8xl font-black font-display text-wave-accent font-mono z-10"
                >
                  {countdown}
                </motion.div>
              )}

              {/* PLAYING STATE */}
              {gameState === 'playing' && (
                <div id="playing-crises-stage" className="absolute inset-0">
                  {/* Progress Indicator */}
                  <div className="absolute top-4 left-4 text-[10px] font-mono text-slate-500 bg-slate-900/80 px-2.5 py-1 rounded border border-slate-800">
                    ROUND: <span className="text-wave-accent font-bold">{currentCrisisIndex + 1} / 5</span>
                  </div>

                  {crises.map((crisis) => (
                    <motion.button
                      key={crisis.id}
                      id={`crisis-bubble-${crisis.id}`}
                      onClick={() => handleCrisisClick(crisis.id)}
                      initial={{ scale: 0.2, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      exit={{ scale: 1.2, opacity: 0 }}
                      transition={{ type: 'spring', damping: 15 }}
                      style={{
                        position: 'absolute',
                        left: crisis.x,
                        top: crisis.y,
                        width: crisis.size,
                        height: crisis.size / 2.2, // wide shape
                        transform: 'translate(-50%, -50%)',
                      }}
                      className={`rounded-2xl border-2 flex flex-col items-center justify-center p-3 font-semibold text-center cursor-pointer shadow-lg hover:scale-105 active:scale-95 transition-transform ${crisis.color}`}
                    >
                      <span className="text-[11px] md:text-xs font-bold leading-tight select-none">
                        {crisis.title}
                      </span>
                      <span className="text-[9px] font-mono text-slate-400 mt-1 select-none font-bold">
                        🚨 CLICK FAST!
                      </span>
                    </motion.button>
                  ))}
                </div>
              )}

              {/* RESULT STATE */}
              {gameState === 'result' && currentRating && (
                <motion.div
                  key="result"
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0 }}
                  className="flex flex-col items-center text-center p-6 max-w-md relative z-10 space-y-4"
                >
                  <div className="w-12 h-12 rounded-full bg-slate-900 border border-slate-800 flex items-center justify-center text-xl">
                    🏆
                  </div>
                  <div id="result-stat-row">
                    <span className="text-xs text-slate-500 uppercase tracking-widest font-mono">평균 반응 속도</span>
                    <div className="text-4xl md:text-5xl font-black font-mono text-white mt-1 animate-bounce">
                      {averageTime} <span className="text-lg text-slate-400 font-bold">ms</span>
                    </div>
                  </div>

                  <div id="result-badge-card" className="bg-slate-900/90 border border-slate-800 p-4 rounded-xl text-left space-y-1.5">
                    <div className="flex items-center gap-2">
                      <span className={`text-xs font-bold font-mono px-2 py-0.5 rounded bg-slate-950/60 border border-slate-800 ${currentRating.color}`}>
                        {currentRating.badge}
                      </span>
                      <h6 className="text-sm font-bold text-slate-100">{currentRating.title}</h6>
                    </div>
                    <p className="text-xs text-slate-400 leading-relaxed">
                      {currentRating.desc}
                    </p>
                  </div>

                  <button
                    id="retry-reflex-btn"
                    onClick={startTest}
                    className="flex items-center gap-2 px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-bold rounded-lg hover:scale-105 transition-all duration-300 cursor-pointer"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>테스트 다시하기</span>
                  </button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </section>
  );
}
