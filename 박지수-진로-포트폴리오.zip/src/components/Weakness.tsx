import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { AlertTriangle, CheckSquare, Square, ThumbsUp, RefreshCw, Sparkles, Moon, HelpCircle } from 'lucide-react';

interface MitigationRule {
  id: string;
  title: string;
  description: string;
  impact: number;
}

export default function Weakness() {
  const [completedRules, setCompletedRules] = useState<string[]>(['rule-1', 'rule-3']); // Default completed

  const rules: MitigationRule[] = [
    {
      id: 'rule-1',
      title: '📋 할 일 원자 단위로 쪼개기 (Task Atomization)',
      description: '침대에서 벗어나기 힘든 날에는 할 일을 1/10 수준으로 쪼갭니다. 책 전체 보기가 아닌 "노션 첫 행 제목 쓰기" 같은 아주 간단한 액션으로 시작 장벽을 제로로 만듭니다.',
      impact: 25
    },
    {
      id: 'rule-2',
      title: '⏳ 이틀 데드라인 선반영 규칙 (Deadline Buffer)',
      description: '나의 또 다른 무기인 "벼락치기 초집중 순발력"을 안전하게 발휘하기 위해 실제 마감 일자보다 이틀 앞서 마감을 강제 설정합니다.',
      impact: 20
    },
    {
      id: 'rule-3',
      title: '🦦 베짱이 휴식 시간 연동 보증 (Proportional Slacking)',
      description: '단순한 집중 강요는 거부감을 낳습니다. 25분간 완벽주의를 내려놓고 빠르게 과제를 돌파하면, 완전한 자유 농땡이 15분을 보장하는 철저한 보상 시스템을 가동합니다.',
      impact: 25
    },
    {
      id: 'rule-4',
      title: '💻 수동 과정 완전 배제 (Automation Check)',
      description: '매번 노션을 켜거나 엑셀 양식을 만드는 귀찮음을 이기기 위해 미리 단축키와 자동화 기획 레이아웃을 바탕화면에 고정해 둡니다.',
      impact: 15
    }
  ];

  const handleToggleRule = (id: string) => {
    if (completedRules.includes(id)) {
      setCompletedRules(completedRules.filter((rId) => rId !== id));
    } else {
      setCompletedRules([...completedRules, id]);
    }
  };

  const baseLaziness = 95; // starting laziness index
  const reduction = rules
    .filter((r) => completedRules.includes(r.id))
    .reduce((sum, r) => sum + r.impact, 0);

  const currentLaziness = Math.max(10, baseLaziness - reduction);

  const getStatusLabel = (val: number) => {
    if (val >= 80) return { title: '침대 합체 중 (초위험)', color: 'text-red-400 bg-red-950/40 border-red-900/30' };
    if (val >= 50) return { title: '겨우 일어선 상태 (미온적)', color: 'text-amber-400 bg-amber-950/40 border-amber-900/30' };
    if (val >= 25) return { title: '스마트 최적화 구동 완료 (양호)', color: 'text-emerald-400 bg-emerald-950/40 border-emerald-900/30' };
    return { title: '최고의 고효율 휴식 상태 (완벽)', color: 'text-wave-accent bg-blue-950/40 border-blue-900/30' };
  };

  const status = getStatusLabel(currentLaziness);

  return (
    <section
      id="weakness"
      className="py-24 px-4 bg-gradient-to-b from-navy-900 to-ocean-dark text-white relative overflow-hidden"
    >
      <div id="weakness-bg-overlay" className="absolute inset-0 pointer-events-none opacity-5">
        <div id="weakness-bg-glow" className="absolute bottom-1/4 left-1/4 w-[500px] h-[500px] bg-blue-500 rounded-full filter blur-[150px]"></div>
      </div>

      <div id="weakness-content-wrapper" className="max-w-4xl mx-auto relative z-10">
        {/* Section Header */}
        <div id="weakness-header" className="text-center mb-16">
          <h2 className="text-xs font-mono uppercase tracking-widest text-wave-accent mb-2 flex items-center justify-center gap-2">
            <AlertTriangle className="w-4 h-4 text-amber-400 animate-pulse" /> My Weakness & Strategy
          </h2>
          <h3 className="text-3xl md:text-4xl font-extrabold font-display tracking-tight text-white">
            나의 단점 : 게으름, 그리고 영리한 역발상
          </h3>
          <p className="mt-4 text-slate-400 max-w-2xl mx-auto text-sm md:text-base">
            솔직히 저는 꽤 게으릅니다. 그러나 이 게으름은 저에게{' '}
            <strong className="text-wave-accent">"귀찮은 일은 무조건 가장 효율적인 방법으로 끝내겠다"</strong>는 강력한 효율 기획의 원동력이 됩니다.
          </p>
        </div>

        <div id="weakness-layout" className="grid grid-cols-1 md:grid-cols-12 gap-8 items-stretch">
          {/* List of Measures (Controls) */}
          <div id="weakness-controls-panel" className="md:col-span-7 space-y-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">나의 행동 기획 엔진 가동하기</span>
              <button
                id="reset-weakness-btn"
                onClick={() => setCompletedRules([])}
                className="text-[10px] text-slate-500 hover:text-wave-accent flex items-center gap-1 cursor-pointer"
              >
                <RefreshCw className="w-3 h-3" /> 초기화
              </button>
            </div>

            {rules.map((rule) => {
              const isChecked = completedRules.includes(rule.id);
              return (
                <button
                  key={rule.id}
                  id={`mitigation-rule-btn-${rule.id}`}
                  onClick={() => handleToggleRule(rule.id)}
                  className={`w-full text-left p-4 rounded-xl border transition-all duration-300 flex items-start gap-3 cursor-pointer ${
                    isChecked
                      ? 'bg-slate-900 border-wave-accent/40 text-slate-100 shadow-md shadow-wave-accent/5'
                      : 'bg-slate-950/40 border-slate-800/80 text-slate-400 hover:border-slate-700 hover:bg-slate-900/40'
                  }`}
                >
                  <div id="rule-icon-wrapper" className="mt-0.5 shrink-0 text-wave-accent">
                    {isChecked ? (
                      <CheckSquare className="w-4.5 h-4.5 text-wave-accent" />
                    ) : (
                      <Square className="w-4.5 h-4.5 text-slate-600" />
                    )}
                  </div>
                  <div id="rule-text-content" className="space-y-1">
                    <h4 className={`text-sm font-bold ${isChecked ? 'text-white' : 'text-slate-300'}`}>
                      {rule.title}
                    </h4>
                    <p className="text-xs text-slate-400 leading-relaxed">
                      {rule.description}
                    </p>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Laziness Level Gauge (Visualizer) */}
          <div id="weakness-visualizer-panel" className="md:col-span-5 bg-slate-900/60 border border-slate-800 rounded-2xl p-6 md:p-8 flex flex-col justify-between backdrop-blur-sm">
            <div id="vis-header" className="space-y-2 text-center md:text-left">
              <span className="text-[10px] font-mono text-wave-accent uppercase tracking-widest block">Mitigation Status</span>
              <h4 className="text-base font-bold text-slate-200">지수 학생의 실시간 게으름 지표</h4>
              <p className="text-xs text-slate-500 leading-relaxed">
                액션 아이템을 완수할 때마다 침대에서 벗어나는 동력원이 뿜어져 나옵니다!
              </p>
            </div>

            {/* Huge gauge circle */}
            <div id="vis-radial-gauge" className="my-8 flex justify-center items-center relative">
              <div className="w-40 h-40 rounded-full border-4 border-slate-800 flex flex-col justify-center items-center relative shadow-lg">
                {/* SVG Radial fill */}
                <svg className="absolute inset-0 w-full h-full transform -rotate-90">
                  <circle
                    cx="80"
                    cy="80"
                    r="76"
                    className="stroke-wave-accent fill-none transition-all duration-700"
                    strokeWidth="4"
                    strokeDasharray="477"
                    strokeDashoffset={477 - (477 * currentLaziness) / 100}
                  />
                </svg>
                
                {/* Score value */}
                <div className="text-center z-10">
                  <div className="text-4xl font-black font-mono tracking-tight text-white animate-pulse">
                    {currentLaziness}%
                  </div>
                  <div className="text-[10px] text-slate-400 font-bold uppercase mt-1">
                    LAZINESS INDEX
                  </div>
                </div>
              </div>
            </div>

            {/* Status box */}
            <div id="vis-status" className={`p-4 rounded-xl border text-center ${status.color}`}>
              <div className="text-xs font-bold">{status.title}</div>
              <div className="text-[10px] opacity-80 mt-1">
                {currentLaziness <= 30 
                  ? '🔋 게으름이 최적화된 기획 동력으로 100% 변환되었습니다!' 
                  : '⚠️ 아직 침대 중력권에 사로잡혀 있습니다.'}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
