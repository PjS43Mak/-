export interface GuestbookMessage {
  id: string;
  name: string;
  message: string;
  timestamp: string;
  role?: string;
}

export interface Activity {
  id: string;
  title: string;
  period: string;
  role: string;
  summary: string;
  description: string[];
  tags: string[];
  category: 'school' | 'club' | 'self';
}

export interface Crisis {
  id: string;
  title: string;
  x: number;
  y: number;
  size: number;
  color: string;
}
